video link:
-> https://www.youtube.com/watch?v=TEfXMNGSm4s

anmerkungen:
-> makefiles befinden sich in src/twmailer-client und src/twmailer-server, wobei beide die executables in ./bin geben
-> fürs builden wir libuuid benötigt, welches mit "sudo apt-get install uuid-dev" installiert werden kann